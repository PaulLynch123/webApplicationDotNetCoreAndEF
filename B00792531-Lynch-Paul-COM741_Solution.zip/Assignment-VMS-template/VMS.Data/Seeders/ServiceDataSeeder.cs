using System;
using System.Collections.Generic;
using VMS.Data.Models;
using VMS.Data.Repositories;
using VMS.Data.Services;


namespace VMS.Data.Seeders
{
    public static class ServiceDataSeeder
    {
   
        public static void Seed(IVehicleService svc)
        {    
            // use the service to seed the database with sample data 
            // when running the web project
            svc.Initialise();      

            //create some vehicles

            //data arranged to sort in different orders
            var v1 = svc.AddVehicle(new Vehicle 
            {
                Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2011,12,30),
               RegistrationPlateNumber = "AAA 1111",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Petrol,
               BodyType = Vehicle.BodyOptions.Hatchback,
               NumberOfDoors = 5,
               PhotoUrl = "https://cdn.motor1.com/images/mgl/OOvYR/s1/2021-jaguar-f-type-svr-rendering.jpg"
            }
            );

            var v2 = svc.AddVehicle(new Vehicle 
            {
                Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2002,11,29),
               RegistrationPlateNumber = "BBB 2222",           
               //VehicleAge is auto generated
               ManualTransmission = true,
               Co2Rating = 2,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Hatchback,
               NumberOfDoors = 5,
               PhotoUrl = "https://cdn.motor1.com/images/mgl/0AZZ9/s1/2019-ford-gt-carbon-series.jpg"
            }
            );

            var v3 = svc.AddVehicle(new Vehicle 
            {
                Make = "Renault3",
               Model = "Megane3",
               DateOfFirstRegistration = new DateTime(2013,10,28),
               RegistrationPlateNumber = "CCC 3333",           
               //VehicleAge is auto generated
               ManualTransmission = true,
               Co2Rating = 300,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "https://cdn.motor1.com/images/mgl/GXOpq/s1/2005-renault-megane-renault-sport-225-cup.jpg"
            }
            );

            var v4 = svc.AddVehicle(new Vehicle 
            {
                Make = "Toyota4",
               Model = "Avensis4",
               DateOfFirstRegistration = new DateTime(2004,04,14),
               RegistrationPlateNumber = "DDD 4444",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 44,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Estate,
               NumberOfDoors = 5,
               PhotoUrl = "https://cdn.motor1.com/images/mgl/Kw1rR/s1/2017-toyota-avenis.jpg"
            }
            );

            //create some services for the vehicles
            var ser1_V1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer1",
                ServiceDate = new DateTime(2017,01,25),
                WorkDescription = "THe work done for the ser1_v1 related to the first vehicle. Fixed Bumper",
                CurrentMileage = 11111,
                CostOfService = 111m
            }
           );

           var ser2_V1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer2",
                ServiceDate = new DateTime(2018,02,28),
                WorkDescription = "THe work done for the ser2_v1 related to the first vehicle. Oil, breakes",
                CurrentMileage = 22222,
                CostOfService = 222.2m          //ensure currency shows the two decimal places
            }
           );

           var ser3_V2 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 2,
                //set all other properties
                ServicerName = "Paul Servicer3",
                ServiceDate = new DateTime(2017,03,30),
                WorkDescription = "THe work done for the ser3_v2 related to the second vehicle. Full service, tightened hand break",
                CurrentMileage = 33333,
                CostOfService = 300.33m
            }
           );

           var ser4_V1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer4",
                ServiceDate = new DateTime(2016,04,24),
                WorkDescription = "Longer scentence to make card bigger. The others in the row will extend there size to match and make it look well. The work done for the ser4_v1 related to the first vehicle. Full service, oil change",
                CurrentMileage = 44444,
                CostOfService = 40m
            }
           );

           var ser5_V1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer5",
                ServiceDate = new DateTime(2015,05,25),
                WorkDescription = "THe work done for the ser5_v1 related to the first vehicle. Full service, oil change",
                CurrentMileage = 555,
                CostOfService = 500.50m
            }
           );

           var ser6_V4 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 4,
                //set all other properties
                ServicerName = "Paul Servicer6",
                ServiceDate = new DateTime(2019,06,26),
                WorkDescription = "THe work done for the ser6_v4 related to the fourth vehicle. Half service, tyre change",
                CurrentMileage = 66000,
                CostOfService = 666.66m
            }
           );

            //add info
        }
    }
}
   