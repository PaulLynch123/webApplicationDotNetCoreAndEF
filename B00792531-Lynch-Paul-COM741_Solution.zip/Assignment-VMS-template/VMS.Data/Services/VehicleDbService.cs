using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

using VMS.Data.Models;
using VMS.Data.Repositories;

namespace VMS.Data.Services
{
    // implement each of these methods (removing the thow statements)
    public class VehicleDbService : IVehicleService
    {

        //create the database instance and initialise ONLY FOR DEVELOPMENT
        private readonly VehicleDbContext db;

        public VehicleDbService()
        {
            db = new VehicleDbContext();
        }
        public void Initialise()
        {
            db.Initialise();
        }
       
        // Vehicle Management
        public Vehicle AddVehicle(Vehicle v)
        {
            //check vehicle with same reg number isn't already in the database
            var exists = db.Vehicles.FirstOrDefault(v1 => v1.RegistrationPlateNumber == v.RegistrationPlateNumber);
            if(exists != null)
            {
                return null;
            }
            //make new vehicle
            var v2 = new Vehicle
            {
                Make = v.Make,
                Model = v.Model,
                DateOfFirstRegistration = v.DateOfFirstRegistration,
                RegistrationPlateNumber = v.RegistrationPlateNumber,                //we know its a new reg
                //VehicleAge is auto generated
                ManualTransmission = v.ManualTransmission,
                Co2Rating = v.Co2Rating,
                FuelType = v.FuelType,
                BodyType = v.BodyType,
                NumberOfDoors = v.NumberOfDoors,
                PhotoUrl = v.PhotoUrl
            };
            //add and save to db context
            db.Vehicles.Add(v2);
            db.SaveChanges();

            //return the newly made vehicle 
            return v2;
        }

        public bool DeleteVehicle(int id)
        {
            // delete the vehicle identified by id
        // return true if completed else false
            var veh = GetVehicleById(id);
            if(veh == null)
            {
                return false;               //returns false if not found and therefore not deleted
            }
            db.Vehicles.Remove(veh);
            db.SaveChanges();

            return true;                    //returns boolean true if deleted
        }

        public IList<Vehicle> GetAllVehicles(string orderBy = null)
        {
            //WHAT IF THERE ARE NO VEHICLES??? empty list
            //return db.Vehicles.ToList();
            IList<Vehicle> vehList = new List<Vehicle>();

            switch(orderBy)
            {
                case "Make" :
                    vehList = db.Vehicles.OrderBy(v => v.Make).ToList();
                    break;
                case "FuelType" :
                    vehList = db.Vehicles.OrderBy(v => v.FuelType).ToList();    //orderBy Enum order So... order Enum options alphabetically
                    break;
                case "DateOfFirstRegistration" :
                    vehList = db.Vehicles.OrderBy(v => v.DateOfFirstRegistration).ToList();
                    break;
                default:
                    vehList = db.Vehicles.ToList();
                    break;
            }

            return vehList;
        }
  
        public Vehicle GetVehicleById(int id)
        {
            //vehicle and services list when matching id or null
            return db.Vehicles.Include(v1 => v1.Services).FirstOrDefault(v1 => v1.Id == id);
            //WHAT HAPPENS WHEN THERE IS NO SERVICE???
        }

        public Vehicle UpdateVehicle(int id, Vehicle v)
        {
            //check vehicle exists
            var veh = GetVehicleById(id);
            if(veh == null)
            {
                return null;
            }

            //check reg doesn't exist in another vehile
            var exists = db.Vehicles.FirstOrDefault(v1 => v1.RegistrationPlateNumber == v.RegistrationPlateNumber && v1.Id != id);
            if(exists != null)
            {
                return null;
            }

            //update details from v object
            veh.Make = v.Make;
            veh.Model = v.Model;
            veh.DateOfFirstRegistration = v.DateOfFirstRegistration;
            veh.RegistrationPlateNumber = v.RegistrationPlateNumber;
            //vehicleAge is calculated. TEST RECALCULATED
            veh.ManualTransmission = v.ManualTransmission;
            veh.Co2Rating = v.Co2Rating;
            veh.FuelType = v.FuelType;
            veh.BodyType = v.BodyType;
            veh.NumberOfDoors = v.NumberOfDoors;
            veh.PhotoUrl = v.PhotoUrl;

            //save database context
            db.SaveChanges();
            //return the updated vehicle OR boolean???
            return veh;         
        }


        // Service Management
        public Service AddService(Service s)
        {
            //check if vehicle exists first
            var vehExists = GetVehicleById(s.VehicleId);            //with service eagerly loaded
            if(vehExists == null)
            {
                return null;            //return null if vehicle doesn't exist
            }
            //chekc if related service exists already
            var serExists = vehExists.Services.FirstOrDefault(s1 => s1.ServiceDate == s.ServiceDate && s1.CostOfService == s.CostOfService);
            if(serExists != null)
            {
                return null;            //return null if service already exists (on same date and same price)
            }
            //create service
            var ser = new Service
            {
                //set the foreign key
                VehicleId = vehExists.Id,
                //set all other properties
                ServicerName = s.ServicerName,
                ServiceDate = s.ServiceDate,
                WorkDescription = s.WorkDescription,
                CurrentMileage = s.CurrentMileage,
                CostOfService = s.CostOfService
            };
            //add service
            db.Services.Add(ser);
            db.SaveChanges();
            //return service created
            return ser;
        }

        public Service GetServiceById(int id)
        {
            //return service or null
            return db.Services.FirstOrDefault(s => s.Id == id);
        }

        public bool DeleteService(int id)
        {
            //check service exists and load to context
            var ser = GetServiceById(id);
            if(ser == null)
            {
                return false;                       //false if does not exist
            }
            //delete service
            db.Services.Remove(ser);
            db.SaveChanges();

            return true;                            //true if deleted
        }

    }
}