using System;
using System.ComponentModel.DataAnnotations;

namespace VMS.Data.Models
{
    public class Service
    {     
        //Primary key... so required and auto incremented
        public int Id {get; set;}

        public string ServicerName {get; set;}
        [DataType(DataType.Date)]                           //formatting for Date
        [Required]
        public DateTime ServiceDate {get; set;}
        public string WorkDescription {get; set;}

        [Required]
        public int CurrentMileage {get; set;}
        [DataType(DataType.Currency)]                       //formatting for Currency
        [Required]
        public decimal CostOfService {get; set;}

        //foreign key dependence
        public int VehicleId {get; set;}                    //convention name of Table and Id

        //Navigation
        public Vehicle Vehicle {get; set;}

    }
}