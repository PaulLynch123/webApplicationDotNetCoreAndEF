using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System;

namespace VMS.Data.Models
{      
    public class Vehicle
    {

        public enum FuelOptions
        {
            //alphabetical order for sorting
            Diesel,
            Electric,
            Hybrid,
            Petrol,
        }

        public enum BodyOptions
        {
            //put in order I want them to sort
            Cabrio,
            Coupe,
            Estate,
            Hatchback,
            Saloon,
            Other
        }

        //primary key
       public int Id {get; set;}
       [Required]
       public string Make {get; set;}
       [Required]
       public string Model {get; set;}
       [DataType(DataType.Date)]
       [Display(Name="Initial Registration Date")]
       public DateTime DateOfFirstRegistration {get; set;}
       [Required]
       [Display(Name="Registration Number")]
       public string RegistrationPlateNumber {get; set;}
       public int VehicleAge => (DateTime.Now - DateOfFirstRegistration).Days / 365;            //VehicleAge in years
       [Display(Name="Manual / Auto")]
       public bool ManualTransmission {get; set;}                                               //stored in SQLite as interger 1(true) 0(false)
       [Range (0, 300, ErrorMessage = "Value for {0} must be between {1} and {2}.")]            //range with error message
       [Display(Name="CO2 Rating")]
       public int Co2Rating {get; set;}
       [Display(Name="Fuel")]
       public FuelOptions FuelType {get; set;}
       [Display(Name="Body Type")]
       public BodyOptions BodyType {get; set;}
       [Range (1, 5, ErrorMessage = "Value for {0} should be between {1} and {2}")]
       public int NumberOfDoors {get; set;}
       [Url]                                                                               //providing url validation
       [Display(Name="Photo URL")]
       public string PhotoUrl {get; set;}

       //Navigation
       public ICollection<Service> Services {get; set;}

    }

}