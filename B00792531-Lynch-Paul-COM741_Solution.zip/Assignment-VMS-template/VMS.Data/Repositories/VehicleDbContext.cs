using System;
using VMS.Data.Models;
using Microsoft.EntityFrameworkCore;
//console logging
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace VMS.Data.Repositories
{
    //Inherit from DbContext
    
    public class VehicleDbContext : DbContext
    {
        //One per table in the Database to allow query
        public DbSet<Vehicle> Vehicles {get; set;}

        public DbSet<Service> Services {get; set;}
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //Logger TURN OFF AS AND WHEN
            optionsBuilder
                .UseLoggerFactory(new ServiceCollection()
                    .AddLogging(builder => builder.AddConsole())
                    .BuildServiceProvider()
                    .GetService<ILoggerFactory>()
                )
                //Datebase to use
                .UseSqlite("Filename=VSM.db");
        }
        

        //method to recreate datebase as I develop TURN OFF WHEN COMPLETE
        public void Initialise()
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
        }
    }
}