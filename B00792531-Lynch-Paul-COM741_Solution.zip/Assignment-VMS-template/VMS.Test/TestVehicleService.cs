using System;
using Xunit;

// importing dependencies from the Data Project
using VMS.Data.Models;
using VMS.Data.Services;

namespace VMS.Test
{
    public class TestVehicleService
    {
        //use a service in all tests
        private readonly IVehicleService svc;

        public TestVehicleService()
        {
            //arrange for all in Constructor
            svc = new VehicleDbService();
            //empty database each time
            svc.Initialise();
        }


       // define a set of appropriate tests to test the vehicle service class
        
        [Fact]
       public void GetVehicleById_WhenExist_ReturnObject()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           //NOT USING orderBy PARAMETER
            var ReturnedVehicle = svc.GetVehicleById(1);

           //assert
           Assert.Equal(veh1, ReturnedVehicle);
       }


       [Fact]
       public void GetVehicleById_WhenNotExist_ReturnNull()
       {
           //act
            var ReturnedVehicle = svc.GetVehicleById(1);

           //assert
           Assert.Null(ReturnedVehicle);
       }


       [Fact]
       public void AddVehicle_WhenExists_propertiesMatch()
       {
           //arrange NOT NEEDED, USE GLOABAL ARRANGEMENT

           //act
           var veh1 = new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(1999,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = true,
               Co2Rating = 299,
               FuelType = Vehicle.FuelOptions.Petrol,
               BodyType = Vehicle.BodyOptions.Hatchback,
               NumberOfDoors = 5,
               PhotoUrl = "www.photoUrl.co.uk"
            };
           var veh2 = svc.AddVehicle(veh1);

           //assert
           Assert.NotEqual(veh1.Id, veh2.Id);
           Assert.Equal(0, veh1.Id);
           Assert.Equal(1, veh2.Id);

           Assert.Equal("Ford1", veh2.Make);
           Assert.Equal("Escort1", veh2.Model);
           Assert.Equal(new DateTime (1999,12,30), veh2.DateOfFirstRegistration);
           Assert.Equal("ABC 1234", veh2.RegistrationPlateNumber);
           Assert.Equal(20, veh2.VehicleAge);
           Assert.Equal(true, veh2.ManualTransmission);
           Assert.Equal(299, veh2.Co2Rating);
           Assert.Equal(Vehicle.FuelOptions.Petrol, veh2.FuelType);
           Assert.Equal(Vehicle.BodyOptions.Hatchback, veh2.BodyType);
           Assert.Equal(5, veh2.NumberOfDoors);
           Assert.Equal("www.photoUrl.co.uk", veh2.PhotoUrl);
       }


       [Fact]
       public void AddVehicle_WhenSameReg_ReturnNull()
       {
           //act
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(1999,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 299,
               FuelType = Vehicle.FuelOptions.Hybrid,
               BodyType = Vehicle.BodyOptions.Estate,
               NumberOfDoors = 4,
               PhotoUrl = "www.photoUrl111.co.uk"
            }
           );

            var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               //SAME REGISTRATION NUMBER
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = true,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //assert
           //Assert.Equal(null, veh2);
           Assert.Null(veh2);
       }


        [Fact]
       public void AddVehicle_WhenNotExists_ReturnObject()
       {
           //act
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var veh2 = svc.GetVehicleById(veh1.Id);

           //assert
           Assert.Equal(1, veh1.Id);
           Assert.Equal("Ford2", veh1.Make);
           Assert.Equal("Escort2", veh1.Model);
           Assert.Equal(new DateTime (2001,12,30), veh1.DateOfFirstRegistration);
           Assert.Equal("CBA 4321", veh1.RegistrationPlateNumber);
           Assert.Equal(18, veh1.VehicleAge);
           Assert.Equal(false, veh1.ManualTransmission);
           Assert.Equal(1, veh1.Co2Rating);
           Assert.Equal(Vehicle.FuelOptions.Diesel, veh1.FuelType);
           Assert.Equal(Vehicle.BodyOptions.Coupe, veh1.BodyType);
           Assert.Equal(3, veh1.NumberOfDoors);
           Assert.Equal("www.photoUrl321.co.uk", veh1.PhotoUrl);

           Assert.Equal(veh1, veh2);

           Assert.Equal(1, veh2.Id);
           Assert.Equal("Ford2", veh2.Make);
           Assert.Equal("Escort2", veh2.Model);
           Assert.Equal(new DateTime (2001,12,30), veh2.DateOfFirstRegistration);
           Assert.Equal("CBA 4321", veh2.RegistrationPlateNumber);
           Assert.Equal(18, veh2.VehicleAge);
           Assert.Equal(false, veh2.ManualTransmission);
           Assert.Equal(1, veh2.Co2Rating);
           Assert.Equal(Vehicle.FuelOptions.Diesel, veh2.FuelType);
           Assert.Equal(Vehicle.BodyOptions.Coupe, veh2.BodyType);
           Assert.Equal(3, veh2.NumberOfDoors);
           Assert.Equal("www.photoUrl321.co.uk", veh2.PhotoUrl);
       }


       [Fact]
       public void DeleteVehicle_NotExist_ReturnFalse()
       {
           //act
           var vehExists = svc.DeleteVehicle(1);
           //assert
           Assert.False(vehExists);
       }


        [Fact]
       public void DeleteVehicle_WhenExists_ReturnTrue()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
            var deleted = svc.DeleteVehicle(veh1.Id);
            var vehReturned = svc.GetVehicleById(1);
           //assert
           Assert.True(deleted);
           //assert null from get Vehicle
           Assert.Null(vehReturned);
       }

         [Fact]
       public void GetAllVehicles_WhenExist_ReturnThree()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "BBC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh3 = svc.AddVehicle(
               new Vehicle
           {
               Make = "AaaFord3",
               Model = "Escort3",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "BBB 2233",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           //act
            var allVehiclesList = svc.GetAllVehicles();
            var listCount = allVehiclesList.Count;
           //assert
           Assert.Equal(3, listCount);
       }


       [Fact]
       public void GetAllVehicles_WhenNotExist_ReturnZero()
       {
           //act
            var allVehiclesList = svc.GetAllVehicles();
            var listCount = allVehiclesList.Count;
           //assert
           Assert.Equal(0, listCount);
       }


       [Fact]
       public void GetAllVehicles_WhenExist_ReturnOrderedLists()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2018,12,30),
               RegistrationPlateNumber = "BBC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Electric,
               BodyType = Vehicle.BodyOptions.Estate,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2010,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Petrol,
               BodyType = Vehicle.BodyOptions.Hatchback,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh3 = svc.AddVehicle(
               new Vehicle
           {
               Make = "AaaFord3",
               Model = "Escort3",
               DateOfFirstRegistration = new DateTime(1985,12,30),
               RegistrationPlateNumber = "BBB 2233",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Hybrid,
               BodyType = Vehicle.BodyOptions.Cabrio,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var veh4 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford4",
               Model = "AaaEscort4",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "BCC 2233",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           //NOT USING orderBy PARAMETER
            var allVehiclesList = svc.GetAllVehicles();
            var listCount = allVehiclesList.Count;
            var firstVehUnordered = allVehiclesList[0];

            //USING orderBy PARAMETER
            var allVehiclesListByMake = svc.GetAllVehicles("Make");
            var firstVehByMake = allVehiclesListByMake[0];
            //Enum order by order created in Model
            var allVehiclesListByFuelType = svc.GetAllVehicles("FuelType");
            var firstVehByFuelType = allVehiclesListByFuelType[0];

            var allVehiclesListByRegDate = svc.GetAllVehicles("DateOfFirstRegistration");
            var firstVehByRegDate = allVehiclesListByRegDate[0];

           //assert
           Assert.Equal(4, listCount);
           Assert.Equal("Ford1", firstVehUnordered.Make);
            //ensure ordering works
           Assert.Equal("AaaFord3", firstVehByMake.Make);
           Assert.Equal("Ford4", firstVehByFuelType.Make);
           Assert.Equal("AaaFord3", firstVehByRegDate.Make);
       }

        
       [Fact]
       public void UpdateVehicle_WhenTwoExist_ReturnUpdatedObject()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var updatedVeh = svc.UpdateVehicle(1,
               new Vehicle
           {
               Make = "FordUpdated",
               Model = "EscortUpdated",
               DateOfFirstRegistration = new DateTime(2010,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = true,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var returned = svc.GetVehicleById(1);

           //assert
           Assert.Equal(returned, updatedVeh);
           //ensure age is recalculated
           Assert.Equal(returned.VehicleAge, 9);
       }


       [Fact]
       public void UpdateVehicle_WhenSameReg_ReturnNull()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );
           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var updatedVeh = svc.UpdateVehicle(1,
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var returned = svc.GetVehicleById(1);

           //assert
           Assert.Null(updatedVeh);
           Assert.Equal(returned, veh1);
           Assert.Equal(returned.RegistrationPlateNumber, "ABC 1234");
       }


       [Fact]
       public void UpdateVehicle_WhenIdNotExist_ReturnNull()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var updatedVeh = svc.UpdateVehicle(2,
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var returned = svc.GetVehicleById(1);

           //assert
           Assert.Null(updatedVeh);
           Assert.Equal(returned, veh1);
           Assert.Equal(returned.Make, "Ford1");
       }


       [Fact]
       public void AddService_WhenNoVehicle_ReturnNull()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var ser = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 2,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           //assert
           Assert.Null(ser);
       }


       [Fact]
       public void AddService_WhenServiceAlreadyExists_ReturnNull()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var ser = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           var serConflict = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Paul Servicer",
                //date same
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 35013,
                //cost same
                CostOfService = 55.63m
            }
           );

           var serNotConflict = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Paul Servicer",
                //date smae
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 35013,
                //cost different
                CostOfService = 12355.63m
            }
           );

           //assert
           Assert.Null(serConflict);
           Assert.Equal(2, serNotConflict.Id);
       }


       [Fact]
       public void AddService_WhenVehicle_ReturnService()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           //act
           var ser = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           //assert
           Assert.Equal(1, ser.VehicleId);
           Assert.Equal("Ms Servicer", ser.ServicerName);
           Assert.Equal(new DateTime(2017,12,25), ser.ServiceDate);
           Assert.Equal("THe work description is likely to be fairly long so I will continue to type for a little while"
           , ser.WorkDescription);
           Assert.Equal(25013, ser.CurrentMileage);
           Assert.Equal(55.63m, ser.CostOfService);
           //check that vehicle is accessable too
           Assert.Equal("Escort1", ser.Vehicle.Model);
       }


       [Fact]
       public void GetVehicleById_WithServices_returnIncludeServices()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var veh2 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford2",
               Model = "Escort2",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "CBA 4321",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var ser = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );
           //act
           //NOT USING orderBy PARAMETER
            var ReturnedVehicle = svc.GetVehicleById(1);
            //ICollection to Array for access
            Service[] copyArray = new Service[5]; 
            ReturnedVehicle.Services.CopyTo(copyArray, 0);
            var serReturned = copyArray[0];

           //assert
           //check service is accessable
           Assert.Equal(1, ReturnedVehicle.Services.Count);
           Assert.Equal(25013, serReturned.CurrentMileage);
       }


       [Fact]
       public void DeleteVehicle_WithServices_CascadeDeleteServices()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var ser1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           var ser2 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Paul Servicer",
                ServiceDate = new DateTime(2018,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 5555.63m
            }
           );
           //act
           var vehDeleted = svc.DeleteVehicle(1);
            //attempt to get deleted vehicle
            var ReturnedVehicle = svc.GetVehicleById(1);
            //attempt to get cascade deleted service
            var serReturned = svc.GetServiceById(1);

           //assert
           Assert.True(vehDeleted);
           //can't find any Vehicle
           Assert.Null(ReturnedVehicle);
           //Can't find any services
           Assert.Null(serReturned);
       }


       [Fact]
       public void GetServiceById_WhenNoService_ReturnNull()
       {
           //act
           var ser = svc.GetServiceById(1);
           //assert
           Assert.Null(ser);
       }


       [Fact]
       public void GetServiceById_WhenServiceExists_ReturnService()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var ser1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           var ser2 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Paul Servicer",
                ServiceDate = new DateTime(2018,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 5555.63m
            }
           );
           //act
           var serReturned = svc.GetServiceById(2);
           //assert
           Assert.Equal(5555.63m, serReturned.CostOfService);
       }


       [Fact]
       public void DeleteService_WhenServiceExists_ReturnTrue()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var ser1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           var ser2 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Paul Servicer",
                ServiceDate = new DateTime(2018,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 5555.63m
            }
           );

           //act
           var serDeleted = svc.DeleteService(1);

           var serReturned = svc.GetServiceById(1);

           //assert
           Assert.True(serDeleted);
           Assert.Null(serReturned);
       }


       [Fact]
       public void DeleteService_WhenNoService_ReturnFalse()
       {
           //arrange more
           var veh1 = svc.AddVehicle(
               new Vehicle
           {
               Make = "Ford1",
               Model = "Escort1",
               DateOfFirstRegistration = new DateTime(2001,12,30),
               RegistrationPlateNumber = "ABC 1234",           
               //VehicleAge is auto generated
               ManualTransmission = false,
               Co2Rating = 1,
               FuelType = Vehicle.FuelOptions.Diesel,
               BodyType = Vehicle.BodyOptions.Coupe,
               NumberOfDoors = 3,
               PhotoUrl = "www.photoUrl321.co.uk"
            }
           );

           var ser1 = svc.AddService(new Service
            {
                //set the foreign key
                VehicleId = 1,
                //set all other properties
                ServicerName = "Ms Servicer",
                ServiceDate = new DateTime(2017,12,25),
                WorkDescription = "THe work description is likely to be fairly long so I will continue to type for a little while",
                CurrentMileage = 25013,
                CostOfService = 55.63m
            }
           );

           //act
           var serDeleted = svc.DeleteService(2);

           var serReturned1 = svc.GetServiceById(1);
           var serReturned2 = svc.GetServiceById(2);


           //assert
           Assert.False(serDeleted);
           //ensure doesn't delete wrong service that exists
           Assert.Equal(ser1, serReturned1);
       }


    }
}