using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VMS.Web.ViewModels
{
    public class ServicesViewModel
    {
        //selectlist of services(only attributed required... id, date, servicer) UNUSED AT THIS POINT
    public SelectList Vehicles {set; get;}

    //info in the form dropdown
    [Required]
    [Display(Name="select vehicle")]
    public int VehicleId {get; set;}

     public string ServicerName {get; set;}
    [DataType(DataType.Date)]                           //formatting for Date
    [Required]
    public DateTime ServiceDate {get; set;}
    public string WorkDescription {get; set;}

    public int CurrentMileage {get; set;}
    [DataType(DataType.Currency)]                       //formatting for Currency
    [Required]
    public decimal CostOfService {get; set;}

    }
}