/*
using System;
using System.Web;

namespace VMS.Web.ViewModels
{
    public class BodyOptionsSelect
    {
        public SelectList BodyOptionsDropdown{get; set;}

    }
}

DIDN'T GET COMPLETED
*/