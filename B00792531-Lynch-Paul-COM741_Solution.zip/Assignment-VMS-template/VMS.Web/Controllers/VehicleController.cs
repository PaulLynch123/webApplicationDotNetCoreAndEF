using System;

using VMS.Data.Models;
using VMS.Data.Services;
using VMS.Web.ViewModels;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace VMS.Web.Controllers
{

 public class VehicleController : BaseController
 //Includes passable alert info
    {
        private readonly VehicleDbService svc;

        public VehicleController()
        {
            //NOTE TO SELF: think about dependency injection
            svc = new VehicleDbService();
        }

        public IActionResult Index(string orderBy)
        {
            //use service to get ordered list
            var vehList = svc.GetAllVehicles(orderBy);
            //return list as view
            return View(vehList);
        }


        public IActionResult Create()
        {
            //return the blank form
            return View();
        }

        //Posting the Vehicle/Create form
        [HttpPost]
        public IActionResult Create(Vehicle v)
        {
            //model validated then...
            if(ModelState.IsValid)
            {
                //add the vehicle in the form to the system
                svc.AddVehicle(v);
                //screen goes vehicle page
                return RedirectToAction(nameof(Index));
            }
            //redisplay form with details if validation errors
                return View(v);
        }


        public IActionResult Edit(int id)
        {
            //get vehicle with related services
            var v = svc.GetVehicleById(id);
            //check if null
            if(v == null)
            {
                //NOTE TO SELF: develop an alert and return to a page for NotFOund
                Alert("Error - Vehicle was not found", AlertType.danger);
                return RedirectToAction(nameof(Index));
            }
            //return vehicle found to be edited
            return View(v);
        }

        //post of Edit submit
        [HttpPost]
        public IActionResult Edit(int id, Vehicle v)
        {
            //check status of model validation first
            if(ModelState.IsValid)
            {
                //update vis service
                svc.UpdateVehicle(id, v);
                //move back to the Vehcile/Index page
                return RedirectToAction(nameof(Index));
            }
            //redisplay form details if validation not met
            return View(v);
        }


        public IActionResult Details(int id)
        {
            //get and check vehicle first
            var v = svc.GetVehicleById(id);
            if(v == null)
            {
                //show alert message for not found return to veh list
                Alert("Error - Vehicle was not found", AlertType.danger);
                return RedirectToAction(nameof(Index));
            }
            //return the vehicle from database in view
            return View(v);
        }
        

        //Going to the Delete page
        public IActionResult Delete(int id)
        {
            //get vehicle first
            var v = svc.GetVehicleById(id);
            if(v == null)
            {
                Alert("Error - Vehicle not found", AlertType.danger);
                return RedirectToAction(nameof(Index));
            }
            //return the vehicle from database in view
            return View(v);
        }

//Same name and parameters so new name needed
//Actually deleting vehicle
        [HttpPost]
        public IActionResult DeleteConfirm(int id)
        {
            //attempt to delete vehicle
            var v = svc.DeleteVehicle(id);
            
            if(v)
            {
                //return to the Vehicle List page
                //NOTE TO SELF: alert message confirmation
                Alert("Vehicle was deleted successfully", AlertType.success);
                return RedirectToAction(nameof(Index));
            }
                //NOTE TO SELF: Alert Message and navigation
                Alert("Error - Vehicle was NOT deleted", AlertType.warning);
                //redisplay Delete page of that id
                return RedirectToAction("Delete", new{Id = id});
                
        }


        // -- Services Management -- 

        public IActionResult CreateService(int id)
        {
            var veh = svc.GetVehicleById(id);

            if(veh == null)
            {
                //redirect back to Vehicle List
                //NOTE TO SELF: Alert message
                Alert("Error - Service not created, vehicle not found", AlertType.danger);
                return RedirectToAction(nameof(Index));
            }

            //using ServicesViewModel for collection of data. 
            //initially set the vehicle foreign key
            var svm = new ServicesViewModel {VehicleId = id};

            //return view with blank serviceViewModel
            return View(svm);
        }

        //Binding the ServicesViewModel data for security
        [HttpPost]
        public IActionResult CreateService([Bind("VehicleId, ServicerName, ServiceDate, WorkDescription, CurrentMileage, CostOfService")] ServicesViewModel sv)
        {
            if(ModelState.IsValid)
            {
                //Need new Model.Service to enter as parameter
                var ser = new Service
                {
                    //set the foreign key
                VehicleId = sv.VehicleId,
                //set all other properties
                ServicerName = sv.ServicerName,
                ServiceDate = sv.ServiceDate,
                WorkDescription = sv.WorkDescription,
                CurrentMileage = sv.CurrentMileage,
                CostOfService = sv.CostOfService
                };

                //use service as parameter
                svc.AddService(ser);

                //redirect to 
                return RedirectToAction(nameof(Details), new{ Id = sv.VehicleId});
            }

            //display form for editing
            return View(sv);
        }


        //Going to the Delete Service page
        public IActionResult DeleteService(int id)
        {
            //attempt to delete vehicle
            var s = svc.GetServiceById(id);
            if(s == null)
            {
                //NOTE TO SELF: return to and alert
                Alert("Error - Service was not found", AlertType.danger);
                return RedirectToAction(nameof(Index));
            }
            //return the vehicle from database in view
            return View(s);
        }

//Same name and parameters so new name needed
//Actually deleting service related to Vheicle from Vehicle Details page
        [HttpPost]
        public IActionResult DeleteServiceConfirm(int id)
        {
            //attempt to delete vehicle
            var sDeleted = svc.DeleteService(id);
            
            if(sDeleted)
            {
                //return to the Vehicle List page
                //NOTE TO SELF: alert message confirmation
                Alert("Service was deleted successfully", AlertType.success);
                return RedirectToAction(nameof(Index));
            }
                //NOTE TO SELF: Alert Message and navigation
                Alert("Error - Service was NOT deleted", AlertType.warning);
                //redisplay Delete page of that id
                return RedirectToAction("DeleteService", new{Id = id});
                
        }
        
    }
}