using Microsoft.AspNetCore.Mvc;

namespace VMS.Web.Controllers
{
    public class BaseController : Controller
    {
        public enum AlertType 
        {
            //choices of alert type
            danger,
            info,
            success,
            warning
        }

//default to info if not specified
        public void Alert(string message, AlertType typeOfAlert = AlertType.info)
        {
            //Using TempData attribute to pass info in browser
            TempData["Alert.Message"] = message;
            TempData["Alert.Type"] = typeOfAlert.ToString();
        }

    }//BASECONTROLLER
    
}